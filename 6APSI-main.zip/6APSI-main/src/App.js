import React from 'react';
import LoginPage from './LoginPage'; 

function App() {
  return (
    <div>
      <LoginPage />
    </div>
  );
}

export default App;
